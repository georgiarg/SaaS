// index.js

/*  EXPRESS */

const express = require('express');
const app = express();
const session = require('express-session');


app.use( express.static( "views" ) );
app.set('view engine', 'ejs');


const port = process.env.PORT || 4000;
app.listen(port , () => console.log('App listening on port ' + port));


app.set('view engine', 'ejs');


app.get('/buycredits', (req, res) => {
    const data = req.query.data;
    res.render('pages/buycredits', { data });
 });


    const url = require('url');
