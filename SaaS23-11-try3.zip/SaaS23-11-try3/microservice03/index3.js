// index.js

/*  EXPRESS */

const express = require('express');
const app = express();
const session = require('express-session');
var bodyParser = require('body-parser');
const cors = require('cors');
var mongoose = require('mongoose');
var multer = require('multer');
var csv = require('csvtojson');
require('dotenv').config()
const path = require('path');
const router = express.Router();

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use( express.static( "views" ) );
app.set('view engine', 'ejs');

app.use('/', router);

const port = process.env.PORT || 5000;
app.listen(port , () => console.log('App listening on port ' + port));

  
app.get('/newchart', (req, res) => {
    res.render('pages/newchart');
 });


const url = require('url');

mongoose.connect("mongodb://mongo:27017",{useNewUrlParser: true, useUnifiedTopology: true});

const fs = require('fs')


app.use(express.json())


  app.get('/done', (req, res) => { 
    // Fetch the data from the database
    
       // res.json(newestDocument)
        // Send the cleaned data to the client or perform further processing
        res.render('pages/newchartdone');

      // res.sendFile(path.join(__dirname+'/newchartdone.html'));
       // console.log(newestDocument)
  });
  
  app.get('/mycsv', (req, res) => { 
    // Fetch the data from the database
    
       // res.json(newestDocument)
        // Send the cleaned data to the client or perform further processing
      // res.render('pages/mycsv');
      const csvData = req.query.data;

      // Process or use the CSV data as needed
      // For example, you can save it to a file, parse it, or pass it to a template for rendering
    
      // Here, we will simply send the CSV data as a response to the client
      res.send(csvData);
      // res.sendFile(path.join(__dirname+'/newchartdone.html'));
       // console.log(newestDocument)
  });


  



