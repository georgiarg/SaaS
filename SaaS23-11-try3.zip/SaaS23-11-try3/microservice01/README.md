# MICROSERVICE 1

## Authentication with Google

We used Google OAuth2 Authentication. 

