// index.js

/*  EXPRESS */

const express = require('express');
const app = express();
const session = require('express-session');
const ejs=require('ejs');
const mongoose = require('mongoose');
const moment = require('moment');
var findOrCreate = require('mongoose-findorcreate');
const GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;


mongoose.connect("mongodb://mongo:27017",{useNewUrlParser: true, useUnifiedTopology: true});
mongoose.set('strictQuery', true);


const Schema = mongoose.Schema;

const userSchema = new Schema({
    userId: String,
    name: String,
    credits: {type: Number, default: 0},
    numberofcharts: {type: Number, default: 0},
    lastlogin: Date
});

userSchema.plugin(findOrCreate);
const Users = mongoose.model("user", userSchema);


app.use( express.static( "views" ) );
app.set('view engine', 'ejs');

app.use(session({
    resave: false,
    saveUninitialized: false,
    secret: 'SECRET'
}));


const port = process.env.PORT || 3000;
app.listen(port , () => console.log('App listening on port ' + port));

/*  PASSPORT SETUP  */

const passport = require('passport');
//var userProfile;

app.use(passport.initialize());
app.use(passport.session());

app.set('view engine', 'ejs');



passport.serializeUser(function(user, cb) {
    cb(null, user);
});

passport.deserializeUser(function(obj, cb) {
    cb(null, obj);
});

/*  Google AUTH  */


const GOOGLE_CLIENT_ID = '409614450296-shlj6jv2hsio989olo0lltra28aq3pgd.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = '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';
passport.use(new GoogleStrategy({
    clientID: GOOGLE_CLIENT_ID,
    clientSecret: GOOGLE_CLIENT_SECRET,
    callbackURL: "http://localhost:3000/auth/google/secret"
  },
  async function(token, tokenSecret, profile, done) {
    const id = { userId: profile.id };
    const update = { lastlogin: Date.now() };

    try {
      const user = await Users.findOneAndUpdate(id, update);
      if (user) {
        return done(null, user);
      } else {
        const newUser = await Users.create({ userId: profile.id, name: profile.displayName });
        return done(null, newUser);
      }
    } catch (err) {
      return done(err);
    }
  }
));


app.get('/auth/google/secret', 
passport.authenticate('google', {failureRedirect: '/'}),
function(req,res){
    res.redirect('/success');
});

app.get('/', function(req, res) {
    if (req.isAuthenticated()){
        res.render("pages/success", {username: req.user.name});
    }
    else{
        res.render('pages/auth');
    }
});

app.locals.moment = moment;

// ...

// Inside the route handler for '/success'
app.get('/success', function(req, res){
    if(req.isAuthenticated()){
        res.render('pages/success', {
            username: req.user.name,
            login: req.user.lastlogin,
            numberofcharts: req.user.numberofcharts,
            credits: req.user.credits
        });
    }
});

app.get("/logout", function(req, res){
    req.logout();
    res.redirect("/");
});
app.get('/mycharts', (req, res) => res.render('pages/mycharts') );

//app.get('/error', (req, res) => res.send("error logging in"));
app.get('/aboutus', (req, res) => res.render('pages/AboutUs') );

app.get('/auth/google',
    passport.authenticate('google', { scope : ['https://www.googleapis.com/auth/plus.login']}));


const url = require('url');